# ML-2 Handoff Document

Artifacts Location:

model_artifacts/

Available Models:

1. Price Model
2. Marketing Model
3. Headcount Model

Output Contract:

{
  "decision_type": "",
  "model_used": "",
  "model_version": "",
  "confidence_score": 0,
  "predicted_kpis": {},
  "deltas": {}
}

Consumers:
- Web Team
- GenAI Team
- API Team
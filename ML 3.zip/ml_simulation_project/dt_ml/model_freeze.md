# Model Freeze Record

Date:
Week 7

Frozen Artifacts:

- price_model.joblib
- marketing_model.joblib
- headcount_model.joblib

Version:

v2

Status:

Frozen For Production
# ML-2 Model Documentation

## Price Model

Model Type:
Log-Log Linear Regression

Purpose:
Estimate revenue impact of price changes.

Inputs:
- price_per_unit
- units_sold

Outputs:
- revenue_delta_pct
- revenue_delta_abs
- churn_delta_pct

Version:
v2

---

## Marketing Model

Model Type:
Square Root Response Model

Purpose:
Estimate customer acquisition impact of marketing spend changes.

Inputs:
- budget
- conversion

Outputs:
- new_customers_delta
- cac_new

Version:
v2

---

## Headcount Model

Model Type:
Headcount Cost Simulator

Purpose:
Estimate workforce cost impact.

Inputs:
- salary

Outputs:
- cost_delta_abs
- cost_delta_pct

Version:
v2
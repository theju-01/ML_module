import json
import os
import joblib

os.makedirs(
    "model_artifacts",
    exist_ok=True
)

price_metadata = {
    "model_name":
        "price_model",
    "version":
        "v2",
    "model_type":
        "Log-Log Linear Regression",
}

marketing_metadata = {
    "model_name":
        "marketing_model",
    "version":
        "v2",
    "model_type":
        "Square Root Response",
}

headcount_metadata = {
    "model_name":
        "headcount_model",
    "version":
        "v2",
    "model_type":
        "Headcount Cost Simulator",
}

joblib.dump(
    price_metadata,
    "model_artifacts/price_model.joblib"
)

joblib.dump(
    marketing_metadata,
    "model_artifacts/marketing_model.joblib"
)

joblib.dump(
    headcount_metadata,
    "model_artifacts/headcount_model.joblib"
)

metadata = {
    "price_model":
        price_metadata,
    "marketing_model":
        marketing_metadata,
    "headcount_model":
        headcount_metadata,
}

with open(
    "model_artifacts/model_metadata.json",
    "w"
) as f:

    json.dump(
        metadata,
        f,
        indent=4
    )

print(
    "All artifacts exported successfully."
)
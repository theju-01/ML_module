import os


def test_artifacts_folder_exists():

    assert os.path.exists(
        "model_artifacts"
    )